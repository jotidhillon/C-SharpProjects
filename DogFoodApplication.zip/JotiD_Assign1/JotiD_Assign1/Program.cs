﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace JotiD_Assign1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Display banner to output the banner method
            DisplayBanner();

            //Writes the first 50 *'s created for the banner
            WriteLine(new string('*', 50));
            WriteLine("* {0, 42}{1, -4} *", "Dog Food Brands in Stock Listed Below", "");
            //First DogFood FoodObject created with the name Zignature and price for each can unit
            DogFood FoodObject1 = new DogFood("Zignature ", 3.00, 1);
            
            //Writes the output for the first FoodObject1 Zignature
            WriteLine("* {0, 5}{1,0}{2, -5} *", " ", FoodObject1, " ");
            
            //Second DogFood FoodObject created with the name Canin and price for each can unit
            DogFood FoodObject2 = new DogFood("Canin ", 7.50, 1);
            
            //Writes the output for the second FoodObject2 Canin
            WriteLine("* {0, 5}{1,0}{2, -9} *", " ", FoodObject2, " ");

            //Third DogFood FoodObject created with the name Purina and price for each can unit
            DogFood FoodObject3 = new DogFood("Purina ", 5.99, 1);
            
            //Writes the output for the third FoodObject3 Purina
            WriteLine("* {0, 5}{1,0}{2, -8} *", " ", FoodObject3, " ");
            
            //outputs the lower half banner
            WriteLine(new string('*', 50));

            //Shows the number of cans for each object
            WriteLine("\nLet us begin by entering the number of cans you need for each of these dog food brands...\n");
            UpdateNumCans(FoodObject1);
            UpdateNumCans(FoodObject2);
            UpdateNumCans(FoodObject3);
            WriteLine("\nThe number of cans for each brand name has been entered.\n");

            //Performs actions for view, update or quitting application
            PerformAction(FoodObject1, FoodObject2, FoodObject3);
        }
        //Display banner formatted output created for the Dog Food Company
        static void DisplayBanner()
        {
            WriteLine(new string('*', 50));
            WriteLine("* {0, 42}{1, -4} *", "Joti Dhillon's Woofyum Dog Food Company", "");
            WriteLine("* {0, 30}{1, -16} *", "Ordering System", "");
            WriteLine("* {0, 33}{1, -13} *", "Place your orders now!", "");
            WriteLine(new string('*', 50));

        }
        //method definition for UpdateNumCans
        static void UpdateNumCans(DogFood anyDogFood)
        {
            //Creates a string for the brand Names 
            string brandName = anyDogFood.BrandName;
            //Outputs the WriteLine for the brandNames
            WriteLine("\nEnter the number of cans for " + brandName);
            //Parses the NumCans variable to read the integer
            anyDogFood.NumCans = int.Parse(ReadLine());
        }
        //method definition for PerformAction (View Order, Update Order or Quit)
        static void PerformAction(DogFood DogFood1, DogFood DogFood2, DogFood DogFood3)
        {
            WriteLine("\n\nWhat would you like to do?");
            //Reads key presses 1, 2 or 3 to engage in action. The userInput reads the value 1, 2 or 3 through if and else statements
            //The userInput == 1 goes to the ViewOrder method defintion, the userInput == 2 goes to the UpdateOrder method definition while the userInput == 3 goes to the Good Bye line.
            WriteLine("\nPress 1 for View Order, Press 2 for Update Order, Press 3 for quitting the application.");
            int userInput = int.Parse(ReadLine());
            if (userInput == 1)
            {
                ViewOrder(DogFood1, DogFood2, DogFood3);
            }
            else if (userInput == 2)
            {
                UpdateOrder(DogFood1, DogFood2, DogFood3);
            }
            else if (userInput == 3)
            {
                WriteLine("\n\n\nThank you for ordering dog food from Joti Dhillon's Woofyum Dog Food Company. Good Bye!\n\n\n");
            }
            else
            {
                WriteLine("\n\nInvalid Input.\n\n");
            }
        }
        //ViewOrder method definition to compute order summary while displaying the output to view the order details
        static void ViewOrder(DogFood DogFood1, DogFood DogFood2, DogFood DogFood3)
        {
            //Computes the OrderSummary Details for the View Order Display
            ComputeOrderSummary(DogFood1, DogFood2, DogFood3, out double totalBeforeDiscount, out double discountAmount);

            //Displays the strings in a String.Format to write the line for display
            WriteLine("\n\nYour Dog Food Order from Joti Dhillon's Woofyum Dog Food Company\n\n");
            WriteLine(new string('*', 50));
            //String.Format for each variable with the To.String for currency
            string brandName1 = String.Format(DogFood1.BrandName);
            string price1 = String.Format(DogFood1.CanUnitPrice.ToString("C"));
            int numCans1 = (DogFood1.NumCans);
            string brandTotal1 = String.Format(DogFood1.BrandTotal.ToString("C"));
            string brandName2 = String.Format(DogFood2.BrandName);
            string price2 = String.Format(DogFood2.CanUnitPrice.ToString("C"));
            int numCans2 = (DogFood2.NumCans);
            string brandTotal2 = String.Format(DogFood2.BrandTotal.ToString("C"));
            string brandName3 = String.Format(DogFood3.BrandName);
            string price3 = String.Format(DogFood3.CanUnitPrice.ToString("C"));
            int numCans3 = (DogFood3.NumCans);
            string brandTotal3 = String.Format(DogFood3.BrandTotal.ToString("C"));
            string beforeDiscount = String.Format(totalBeforeDiscount.ToString("C"));
            string discountedAmount = String.Format(discountAmount.ToString("C"));
            string amountTotal = String.Format((totalBeforeDiscount - discountAmount).ToString("C"));

            //Output each variable with the WriteLine method call with the StringFormat created with additional formatting
            WriteLine("* {0, 25}{1,-21} *", "Brand Name: ", brandName1);
            WriteLine("* {0, 25}{1,-21} *", "Unit Price: ", price1);
            WriteLine("* {0, 25}{1,-21} *", "Num Cans: ", numCans1);
            WriteLine("* {0, 25}{1,-21} *", "Brand Total: ", brandTotal1);
            
            WriteLine(new string('-', 50));
            WriteLine("* {0, 25}{1,-21} *", "Brand Name: ", brandName2);
            WriteLine("* {0, 25}{1,-21} *", "Unit Price: ", price2);
            WriteLine("* {0, 25}{1,-21} *", "Num Cans: ", numCans2);
            WriteLine("* {0, 25}{1,-21} *", "Brand Total: ", brandTotal2);
            
            WriteLine(new string('-', 50));
            WriteLine("* {0, 25}{1,-21} *", "Brand Name: ", brandName3);
            WriteLine("* {0, 25}{1,-21} *", "Unit Price: ", price3);
            WriteLine("* {0, 25}{1,-21} *", "Num Cans: ", numCans3);
            WriteLine("* {0, 25}{1,-21} *", "Brand Total: ", brandTotal3);

            WriteLine(new string('-', 50));
            WriteLine("* {0, 25}{1,-21} *", "Total Before Discount: ", beforeDiscount);
            WriteLine("* {0, 25}{1,-21} *", "Discount: ", discountedAmount);
            WriteLine("* {0, 25}{1,-21} *", "Total after Discount: " + "", amountTotal);
            WriteLine(new string('*', 50));

            //PerformAction Method Call gives option to perform action again (View Order, Update Order or Quit)
            PerformAction(DogFood1, DogFood2, DogFood3);
        }
        //Double ComputeOrderSummary method definition to get the totalBeforeDiscount while getting the discount amount to find the amount after total discount
        static double ComputeOrderSummary(DogFood DogFood1, DogFood DogFood2, DogFood DogFood3, out double totalBeforeDiscount, out double discountAmount)
        {
            discountAmount = 0;
            //Calculates the TotalBeforeDiscount summing three BrandTotals for each Products
            totalBeforeDiscount = DogFood1.BrandTotal + DogFood2.BrandTotal + DogFood3.BrandTotal;
            //if statement specifying amount must be over $75 for the 15% Discount 
            if (totalBeforeDiscount > 75.00)
            {
                //discountAmount gives totalBeforeDiscount multiplied by 15% returned as double 
                discountAmount = totalBeforeDiscount * 0.15;
                double totalAfterDiscount;
                //returns the totalAfterDiscount 
                return totalAfterDiscount = (totalBeforeDiscount - discountAmount);
            }
            else
            {
                return 0;
            }
        }
        //UpdateOrder method definition by pressing 1, 2 or 3
        static void UpdateOrder(DogFood DogFood1, DogFood DogFood2, DogFood DogFood3)
        {
            WriteLine("\nUpdating your Dog Food Order");
            WriteLine("\nPress 1 to Update Quantities for " + DogFood1.BrandName);
            WriteLine("Press 2 to Update Quantities for " + DogFood2.BrandName);
            WriteLine("Press 3 to Update Quantities for " + DogFood3.BrandName);
            WriteLine("\nPress 1, 2 or 3: ");
            //Reads value 1,2 or 3 in if else statement. userInput checks the ReadLine key value for 1, 2 or 3.
            //If Else statement goes through the iteration to output the specified information for the userInput 1, 2 or 3
            int userInput = int.Parse(ReadLine());
            if (userInput == 1)
            {

                WriteLine("\nEnter the Quantity of Cans for " + DogFood1.BrandName);
                DogFood1.NumCans = int.Parse(ReadLine());
                WriteLine("\nThe Quantity for " + DogFood1.BrandName + "has been updated to " + DogFood1.NumCans);
            }
            else if (userInput == 2)
            {

                WriteLine("\nEnter the Quantity of Cans for " + DogFood2.BrandName);
                DogFood2.NumCans = int.Parse(ReadLine());
                WriteLine("\nThe Quantity for " + DogFood2.BrandName + "has been updated to " + DogFood2.NumCans);
            }
            else if (userInput == 3)
            {

                WriteLine("\nEnter the Quantity of Cans for " + DogFood3.BrandName);
                DogFood3.NumCans = int.Parse(ReadLine());
                WriteLine("\nThe Quantity for " + DogFood3.BrandName + "has been updated to " + DogFood3.NumCans);
            }
            else
            {
                WriteLine("\n\nRequire Valid Input. Please enter valid number 1, 2 or 3.");
            }
            //Performs the action for the method call again to View Order, Update Order or Quit Application
            PerformAction(DogFood1, DogFood2, DogFood3);
        }
    }
}
