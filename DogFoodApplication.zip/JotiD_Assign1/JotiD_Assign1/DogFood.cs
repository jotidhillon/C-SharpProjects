﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JotiD_Assign1
{
    internal class DogFood
    {
        //Read-only property with the string variable for BrandName with the get, meaning that the read-only property can't be changed afterwards
        public string BrandName
        {
            get;
        }
        //Read-only property with the double variable for CanUnitPrice with the get to only get the read-only property, which cannot be changed afterwards
        public double CanUnitPrice
        {
            get;
        }
        //Read-Write Property for NumCans which can be changed afterwards
        public int NumCans
        {
            get; set;
        }
        //Read-only Computed Property for BrandTotal computing return of NumCans multiplied by CanUnitPrice
        public double BrandTotal
        {
            get
            {
                return NumCans * (CanUnitPrice);
            }
        }
        //Constructor for the brand, price, cans to use in the program
        public DogFood(string brand, double price, int cans)
        {
            BrandName = brand;
            CanUnitPrice = price;
            NumCans = cans;
        }
        //Overrride ToString() to output the String.Format for the variables. The .ToString formats the currency
        public override string ToString()
        {
            string outputStr = "Brand Name: " + BrandName + "\n" +
                                "Unit Price: " + CanUnitPrice + "\n" +
                                "Num Cans: " + NumCans + "\n" +
                                "Brand Total: " + BrandTotal + "\n";
            return String.Format("Can Unit Price for " + BrandName + ": " + CanUnitPrice.ToString("C"));
        }
    }
}
